/*
 * SPDX-FileCopyrightText: 2026 Tim Schneeberger
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package me.timschneeberger.shizustore.data.model

import androidx.compose.runtime.Immutable
import kotlinx.serialization.Serializable

@Serializable
enum class AppSort { NAME, RECENTLY_ADDED, RECENTLY_UPDATED, STARS, DOWNLOADS, TRENDING, SIZE_DESC }

/** Price buckets. IAP and IAP_OR_PAID overlap by design; FREE is disjoint from both. */
@Serializable
enum class AppPrice { FREE, IAP, IAP_OR_PAID }

@Immutable
@Serializable
data class AppListArgs(
    val query: String = "",
    val categorySlug: String? = null,
    val price: AppPrice? = null,
    val recommended: Boolean = false,
    val sort: AppSort = AppSort.NAME
) {
    val isSearchHome: Boolean
        get() = query.isBlank() &&
            categorySlug == null &&
            price == null &&
            !recommended &&
            sort == AppSort.NAME
}
