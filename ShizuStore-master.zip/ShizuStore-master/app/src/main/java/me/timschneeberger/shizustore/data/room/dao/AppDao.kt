/*
 * SPDX-FileCopyrightText: 2026 Tim Schneeberger
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package me.timschneeberger.shizustore.data.room.dao

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Query
import androidx.room.RawQuery
import androidx.room.Transaction
import androidx.room.Upsert
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow
import me.timschneeberger.shizustore.data.api.Listing
import me.timschneeberger.shizustore.data.room.entity.AppEntity
import me.timschneeberger.shizustore.data.room.entity.mergeDetailFrom

@Dao
interface AppDao {

    @Query("SELECT * FROM app WHERE slug = :slug")
    suspend fun get(slug: String): AppEntity?

    @Query("SELECT * FROM app WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): AppEntity?

    /** A flavor package lives on app_download, not on the app's canonical packageName. */
    @Query(
        "SELECT * FROM app WHERE slug IN" +
            " (SELECT appSlug FROM app_download WHERE packageName = :packageName) LIMIT 1"
    )
    suspend fun getByDownloadPackage(packageName: String): AppEntity?

    @Query("SELECT * FROM app WHERE slug = :slug")
    fun observe(slug: String): Flow<AppEntity?>

    @Query("SELECT * FROM app")
    suspend fun getAll(): List<AppEntity>

    @Query("SELECT slug FROM app")
    suspend fun allSlugs(): List<String>

    @Query("SELECT COUNT(*) FROM app")
    suspend fun count(): Int

    @Query(
        "UPDATE app SET installedVersionCode = NULL, updateAvailable = 0," +
            " updateCandidateId = NULL, updateIgnored = 0"
    )
    suspend fun clearUpdateState()

    @Upsert
    suspend fun upsert(app: AppEntity)

    @Query("DELETE FROM app WHERE slug = :slug")
    suspend fun delete(slug: String)

    @Query("DELETE FROM app WHERE slug IN (:slugs)")
    suspend fun deleteBySlugs(slugs: List<String>)

    @Query("DELETE FROM app WHERE listing = :listing")
    suspend fun deleteByListing(listing: Listing)

    @Query("DELETE FROM app")
    suspend fun clear()

    @Transaction
    suspend fun upsertSummaries(summaries: List<AppEntity>) {
        summaries.forEach { summary ->
            upsert(summary.mergeDetailFrom(get(summary.slug)))
        }
    }

    @Query("UPDATE app SET installCount = :count WHERE slug = :slug")
    suspend fun setInstallCount(slug: String, count: Long)

    /** Delta install counts from `installsUpdated`: one narrow column write per row. */
    @Transaction
    suspend fun setInstallCounts(counts: Map<String, Long>) {
        counts.forEach { (slug, count) -> setInstallCount(slug, count) }
    }

    @Query("UPDATE app SET trendScore = NULL")
    suspend fun clearTrendScores()

    @Query("UPDATE app SET trendScore = :score WHERE slug = :slug")
    suspend fun setTrendScore(slug: String, score: Long)

    /** Wholesale rewrite behind the Trending sort: clearing first drops apps that
     * fell out of the window so a stale score cannot keep ranking them. */
    @Transaction
    suspend fun replaceTrendScores(scores: Map<String, Long>) {
        clearTrendScores()
        scores.forEach { (slug, score) -> setTrendScore(slug, score) }
    }

    @Query(
        "UPDATE app SET installedVersionCode = :installedVersionCode," +
            " updateAvailable = :updateAvailable, updateCandidateId = :updateCandidateId," +
            " updateIgnored = :updateIgnored" +
            " WHERE slug = :slug"
    )
    suspend fun setUpdateState(
        slug: String,
        installedVersionCode: Long?,
        updateAvailable: Boolean,
        updateCandidateId: Long?,
        updateIgnored: Boolean
    )

    @RawQuery(observedEntities = [AppEntity::class])
    fun pagedFiltered(query: SupportSQLiteQuery): PagingSource<Int, AppEntity>

    @Query(
        "SELECT * FROM app WHERE updateAvailable = 1 AND updateIgnored = 0" +
            " ORDER BY name COLLATE NOCASE ASC"
    )
    fun pagedUpdatable(): PagingSource<Int, AppEntity>

    @Query("SELECT COUNT(*) FROM app WHERE updateAvailable = 1 AND updateIgnored = 0")
    fun observeUpdatableCount(): Flow<Int>

    /** Updatable rows a notification or unattended pass may act on. */
    @Query(
        "SELECT * FROM app WHERE updateAvailable = 1 AND updateIgnored = 0" +
            " AND packageName IS NOT NULL"
    )
    suspend fun getUpdatable(): List<AppEntity>

    @Query(
        "SELECT * FROM app WHERE installedVersionCode IS NOT NULL ORDER BY name COLLATE NOCASE ASC"
    )
    fun pagedInstalled(): PagingSource<Int, AppEntity>

    /** Whole installed set for bulk actions such as the Obtainium export. */
    @Query(
        "SELECT * FROM app WHERE installedVersionCode IS NOT NULL ORDER BY name COLLATE NOCASE ASC"
    )
    suspend fun getInstalled(): List<AppEntity>

    @Query(
        "SELECT * FROM app ORDER BY listUpdatedAt IS NULL, listUpdatedAt DESC," +
            " name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observeRecentlyAdded(limit: Int): Flow<List<AppEntity>>

    @Query("SELECT * FROM app WHERE isRecommended = 1 ORDER BY slug ASC")
    fun observeRecommendedPool(): Flow<List<AppEntity>>

    /** Other apps sharing a stable developer key, for the "more from this dev" row. */
    @Query(
        "SELECT * FROM app WHERE authorKey = :authorKey AND slug != :excludeSlug" +
            " ORDER BY name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observeByAuthor(authorKey: String, excludeSlug: String, limit: Int): Flow<List<AppEntity>>

    /** Other apps in the same category, for the trailing details shelf. */
    @Query(
        "SELECT * FROM app WHERE categorySlug = :categorySlug AND slug != :excludeSlug" +
            " ORDER BY name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observeByCategory(
        categorySlug: String,
        excludeSlug: String,
        limit: Int
    ): Flow<List<AppEntity>>

    @Query(
        "SELECT * FROM app ORDER BY versionUpdatedAt IS NULL, versionUpdatedAt DESC," +
            " name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observeRecentlyUpdated(limit: Int): Flow<List<AppEntity>>

    /** Null stars (unknown popularity) excluded so the row hides without data. */
    @Query(
        "SELECT * FROM app WHERE stars IS NOT NULL ORDER BY stars DESC," +
            " name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observeMostStarred(limit: Int): Flow<List<AppEntity>>

    /** Zero installs excluded so the row hides on a fresh store. */
    @Query(
        "SELECT * FROM app WHERE installCount > 0 ORDER BY installCount DESC," +
            " name COLLATE NOCASE ASC LIMIT :limit"
    )
    fun observePopular(limit: Int): Flow<List<AppEntity>>

    @Query("SELECT * FROM app ORDER BY slug ASC")
    fun observeAll(): Flow<List<AppEntity>>

    @Query(
        "SELECT a.* FROM app a JOIN favourite f ON f.packageName = a.packageName" +
            " WHERE a.packageName IS NOT NULL ORDER BY a.name COLLATE NOCASE ASC"
    )
    fun pagedFavourites(): PagingSource<Int, AppEntity>

    /** Whole favourite set for bulk actions such as the Obtainium export. */
    @Query(
        "SELECT a.* FROM app a JOIN favourite f ON f.packageName = a.packageName" +
            " WHERE a.packageName IS NOT NULL ORDER BY a.name COLLATE NOCASE ASC"
    )
    suspend fun getFavourites(): List<AppEntity>

    @Query(
        "SELECT a.* FROM app a JOIN ignored_update i ON i.packageName = a.packageName" +
            " WHERE a.packageName IS NOT NULL ORDER BY a.name COLLATE NOCASE ASC"
    )
    fun observeIgnoredUpdates(): Flow<List<AppEntity>>
}
