/*
 * SPDX-FileCopyrightText: 2026 Tim Schneeberger
 * SPDX-FileCopyrightText: 2026 Aurora OSS
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package me.timschneeberger.shizustore.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import androidx.paging.map
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import me.timschneeberger.shizustore.data.model.ResolvedApp
import me.timschneeberger.shizustore.data.repository.AppRepository
import me.timschneeberger.shizustore.data.repository.CatalogUiMapper
import me.timschneeberger.shizustore.data.room.entity.AppEntity

@HiltViewModel
class InstalledViewModel @Inject constructor(
    private val appRepository: AppRepository,
    mapper: CatalogUiMapper
) : ViewModel() {

    val installed: Flow<PagingData<ResolvedApp>> =
        Pager(PagingConfig(pageSize = PAGE_SIZE, enablePlaceholders = false)) {
            appRepository.pagedInstalled()
        }.flow.map { paging -> paging.map(mapper::toResolvedApp) }.cachedIn(viewModelScope)

    /** Full installed list for the Obtainium JSON export, not just the paged window. */
    suspend fun exportCandidates(): List<AppEntity> = appRepository.installedApps()
}
