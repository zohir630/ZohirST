/*
 * SPDX-FileCopyrightText: 2026 Tim Schneeberger
 * SPDX-FileCopyrightText: 2026 Aurora OSS
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Adapted from Droid-ify (GPL-3.0-or-later).
 */

package me.timschneeberger.shizustore.data.network

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection.HTTP_NOT_MODIFIED
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import me.timschneeberger.shizustore.BuildConfig
import me.timschneeberger.shizustore.R
import okhttp3.CacheControl
import okhttp3.Headers
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.BufferedSink
import okio.BufferedSource
import okio.appendingSink
import okio.buffer

@Singleton
class OkHttpDownloader @Inject constructor(
    client: OkHttpClient,
    @ApplicationContext private val context: Context
) : Downloader {

    // Some F-Droid mirrors serve .apk files only to the F-Droid client's
    // User-Agent (the FAU mirror 404s others). APKs are never fetched from
    // non-F-Droid sources, so tag every download; the appended interceptor
    // runs after the base client's agent setter, which it overrides.
    private val client = client.newBuilder()
        .addInterceptor { chain ->
            chain.proceed(
                chain.request().newBuilder()
                    .header(
                        "User-Agent",
                        "${userAgent(
                            context.getString(R.string.app_name),
                            BuildConfig.VERSION_NAME
                        )} F-Droid"
                    )
                    .build()
            )
        }
        .build()

    override suspend fun downloadToFile(
        url: String,
        target: File,
        resume: Boolean,
        headers: Headers.Builder.() -> Unit,
        block: ProgressListener?
    ): NetworkResponse = withContext(Dispatchers.IO) {
        try {
            if (!resume) target.delete()
            val fileSize = target.length()
            val request = request(url) {
                if (fileSize > 0) inRange(fileSize)
                headers()
            }
                // APK bodies must never land in the shared HTTP cache: they are
                // already stored in the downloads dir and would evict icons.
                .cacheControl(CacheControl.FORCE_NETWORK)
                .build()
            client.newCall(request).execute().use { response ->
                val networkResponse = response.asNetworkResponse()
                if (networkResponse !is NetworkResponse.Success) return@use networkResponse

                target.appendingSink().buffer().use { sink ->
                    response.body.source().copyTo(
                        sink = sink,
                        alreadyRead = fileSize,
                        contentLength = response.body.contentLength().takeIf { it >= 0 },
                        block = block
                    )
                }
                networkResponse
            }
        } catch (e: SocketTimeoutException) {
            NetworkResponse.Error.SocketTimeout(e)
        } catch (e: IOException) {
            NetworkResponse.Error.IO(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            NetworkResponse.Error.Unknown(e)
        }
    }

    private suspend fun BufferedSource.copyTo(
        sink: BufferedSink,
        alreadyRead: Long,
        contentLength: Long?,
        block: ProgressListener?
    ) = withContext(Dispatchers.IO) {
        var totalRead = 0L
        while (true) {
            val read = read(sink.buffer, DEFAULT_BUFFER_SIZE.toLong())
            if (read == -1L) break
            sink.emitCompleteSegments()
            totalRead += read
            block?.invoke(
                DataSize(totalRead + alreadyRead),
                contentLength?.let { DataSize(it + alreadyRead) }
            )
        }
    }

    private fun request(url: String, headers: Headers.Builder.() -> Unit): Request.Builder =
        Request.Builder()
            .url(url)
            .headers(Headers.Builder().apply(headers).build())
}

private fun Response.asNetworkResponse(): NetworkResponse =
    if (isSuccessful || code == HTTP_NOT_MODIFIED) {
        NetworkResponse.Success(code)
    } else {
        NetworkResponse.Error.Http(code)
    }
