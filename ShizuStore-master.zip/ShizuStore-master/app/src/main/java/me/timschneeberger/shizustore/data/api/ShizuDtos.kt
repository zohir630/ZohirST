/*
 * SPDX-FileCopyrightText: 2026 Tim Schneeberger
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package me.timschneeberger.shizustore.data.api

import kotlinx.serialization.Serializable

/**
 * Wire models mirroring `Api/Dtos.cs`. Dates stay as raw ISO-8601 strings
 * because the `since` cursor is passed back to the server verbatim.
 */

@Serializable
data class AppSummaryDto(
    val slug: String,
    val name: String = "",
    val description: String = "",
    val license: String? = null,
    val listing: String = "",
    val type: String = "",
    val isRecommended: Boolean = false,
    val hasPaid: Boolean = false,
    val hasIap: Boolean = false,
    val hasAds: Boolean = false,
    val trialDays: Int? = null,
    val requiresRoot: Boolean = false,
    val availability: String = "",
    val packageName: String? = null,
    val versionCode: Long? = null,
    val versionName: String? = null,
    val minSdk: Int? = null,
    val size: Long? = null,
    val iconHash: String? = null,
    val iconAdaptive: Boolean = false,
    val categorySlug: String = "",
    val updatedAt: String = "",
    val sigSha256: String? = null,
    val sigMd5: String? = null,
    val stars: Int? = null,
    val downloadTotal: Long? = null,
    val installCount: Long = 0,
    val versionUpdatedAt: String? = null,
    val listUpdatedAt: String? = null,
    val authorKey: String? = null,
    val authorName: String? = null,
    val sourceName: String? = null,
    // Badging facts from the primary download; null/empty until the server analyzed it.
    val targetSdk: Int? = null,
    val compileSdk: Int? = null,
    val localeCount: Int? = null,
    val abis: List<String> = emptyList(),
    // Locale labels that differ from the display name; empty when the APK ships none.
    val localizedLabels: Map<String, String> = emptyMap(),
    // APK analysis signals from the primary download; empty until the server analyzed it.
    val dhizukuDeclared: Boolean = false,
    val trackers: List<String> = emptyList(),
    val trackerTags: List<TrackerTagDto> = emptyList()
)

@Serializable
data class DownloadDto(
    val source: String = "",
    // The package this flavor installs as; differs from the app's canonical package.
    val packageName: String? = null,
    val apkUrl: String,
    val archiveEntry: String? = null,
    val versionCode: Long? = null,
    val versionName: String? = null,
    val size: Long? = null,
    val sha256: String? = null,
    val sigSha256: String? = null,
    val sigMd5: String? = null,
    val minSdk: Int? = null,
    val abi: String? = null,
    val primary: Boolean = false,
    // Analyzed APK facts; null/empty on index-only rows or pre-analysis versions.
    val targetSdk: Int? = null,
    val compileSdk: Int? = null,
    val locales: List<String> = emptyList(),
    val abis: List<String> = emptyList(),
    // locale -> localized application label (aapt2 `application-label-<locale>`).
    val localizedLabels: Map<String, String> = emptyMap(),
    val signerDn: String? = null,
    val signerScheme: String? = null,
    val signerKeyAlgorithm: String? = null
)

@Serializable
data class CategoryPathDto(
    val slug: String,
    val name: String = ""
)

@Serializable
data class TrackerTagDto(
    val name: String = "",
    val tags: List<String> = emptyList()
)

@Serializable
data class AppDetailDto(
    val slug: String,
    val name: String = "",
    val description: String = "",
    val license: String? = null,
    val listing: String = "",
    val type: String = "",
    val isRecommended: Boolean = false,
    val hasPaid: Boolean = false,
    val hasIap: Boolean = false,
    val hasAds: Boolean = false,
    val trialDays: Int? = null,
    val requiresRoot: Boolean = false,
    val availability: String = "",
    val packageName: String? = null,
    val versionCode: Long? = null,
    val versionName: String? = null,
    val minSdk: Int? = null,
    val iconHash: String? = null,
    val iconAdaptive: Boolean = false,
    val categorySlug: String = "",
    val updatedAt: String = "",
    val url: String? = null,
    val sourceUrl: String? = null,
    val sourceKind: String = "",
    val downloads: List<DownloadDto> = emptyList(),
    val storeUrl: String? = null,
    val excludedReason: String? = null,
    val categoryPath: List<CategoryPathDto> = emptyList(),
    val parentSlug: String? = null,
    val addedAt: String = "",
    val lastCheckedAt: String? = null,
    val stars: Int? = null,
    val downloadTotal: Long? = null,
    val installCount: Long = 0,
    val versionUpdatedAt: String? = null,
    val listUpdatedAt: String? = null,
    val authorName: String? = null,
    val authorUrl: String? = null,
    val permissions: List<String> = emptyList(),
    val fullDescription: String? = null,
    // Direct raw markdown URL of the stored README; the client refetches it live.
    val readmeUrl: String? = null,
    val changelog: String? = null,
    val changelogUrl: String? = null,
    val screenshots: List<String> = emptyList(),
    val sourceName: String? = null,
    // Badging facts from the primary download; the detail adds the full locale list.
    val targetSdk: Int? = null,
    val compileSdk: Int? = null,
    val localeCount: Int? = null,
    val locales: List<String> = emptyList(),
    val abis: List<String> = emptyList(),
    // AI source analysis (server SPEC 5.4); null until the server analyzed the app.
    val usageShort: String? = null,
    val usageMarkdown: String? = null,
    val usageAnalyzedAt: String? = null,
    // APK analysis signals from the primary download; empty until the server analyzed it.
    val dhizukuDeclared: Boolean = false,
    val trackers: List<String> = emptyList(),
    val trackerTags: List<TrackerTagDto> = emptyList()
)

@Serializable
data class CategoryNodeDto(
    val slug: String,
    val name: String = "",
    val section: String = "",
    val appCount: Int = 0,
    val children: List<CategoryNodeDto> = emptyList()
)

@Serializable
data class PagedAppsDto(
    val items: List<AppSummaryDto> = emptyList(),
    val total: Int = 0
)

@Serializable
data class RemovedAppDto(
    val slug: String
)

@Serializable
data class ChangesDto(
    val added: List<AppSummaryDto> = emptyList(),
    val updated: List<AppSummaryDto> = emptyList(),
    val removed: List<RemovedAppDto> = emptyList(),
    // Delta counts applied directly onto stored rows, never as summaries, so a
    // popular app cannot force a detail refetch.
    val installsUpdated: Map<String, Long> = emptyMap(),
    // Operator high-water mark for remote catalog purges; older or absent
    // means no purge. Raw ISO string, parsed only when compared.
    val catalogPurgeRequestedAt: String? = null,
    // Server timestamp captured before the response's reads; the only safe
    // cursor. Null against servers that predate it, then /v1/meta is used.
    val generatedAt: String? = null
)

@Serializable
data class MetaDto(
    val generatedAt: String = "",
    val listCommit: String? = null,
    val useInstallCountsForPopularity: Boolean = false,
    // Null against servers that predate the counts field.
    val counts: MetaCountsDto? = null
)

@Serializable
data class MetaCountsDto(
    val apps: Int = 0,
    val categories: Int = 0
)

@Serializable
data class HealthDto(
    val status: String = ""
)

@Serializable
data class InstallRecordedDto(
    val slug: String = "",
    val installCount: Long = 0
)

/** Install kinds the server accepts in an install report. */
enum class InstallType(val wire: String) {
    FRESH("fresh"),
    UPDATE("update"),
    UNKNOWN("unknown")
}

/** Request body for `POST /v1/apps/{slug}/installs`; no defaults so both fields always encode. */
@Serializable
data class InstallReportDto(
    val versionCode: Long,
    val installType: String
)

@Serializable
data class TrendingItemDto(
    val slug: String = "",
    val installs: Long = 0,
    val previousInstalls: Long = 0,
    val delta: Long = 0
)

@Serializable
data class TrendingDto(
    // Server timestamp captured before the response's reads; not a cursor here,
    // the trending window simply recomputes on the next fetch.
    val generatedAt: String = "",
    val windowDays: Int = 0,
    val sort: String = "",
    val items: List<TrendingItemDto> = emptyList()
)

@Serializable
data class InstallDayDto(
    val day: String = "",
    val count: Long = 0
)

@Serializable
data class StarDayDto(
    val day: String = "",
    val stars: Int = 0
)

/**
 * Per-day history for one app; installs cover the whole window zero-filled,
 * days before the first star snapshot are omitted (not zeroed).
 */
@Serializable
data class AppHistoryDto(
    val slug: String = "",
    val generatedAt: String = "",
    val installs: List<InstallDayDto> = emptyList(),
    val stars: List<StarDayDto> = emptyList()
)
