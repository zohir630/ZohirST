import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.androidx.baselineprofile)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.parcelize)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.google.ksp)
    alias(libs.plugins.hilt.android)
    alias(libs.plugins.ktlint)
}

val lastCommitHash = providers.exec {
    commandLine("git", "rev-parse", "--short", "HEAD")
    isIgnoreExitValue = true
}.standardOutput.asText.map { it.trim() }

val appVersionName = "1.5.0"
val appVersionCode = 150

val hasReleaseKey = File("signing.properties").exists()

androidComponents {
    onVariants { variant ->
        // Applied via the RefineFactory API instead of the Gradle plugin;
        // the plugin only needs to stay on the classpath in the root project.
        variant.instrumentation.transformClassesWith(
            dev.rikka.tools.refine.RefineFactory::class.java,
            com.android.build.api.instrumentation.InstrumentationScope.ALL
        ) {}

        val version = buildString {
            append(appVersionName)
            if (variant.buildType == "nightly") append("-${lastCommitHash.get()}")
        }
        val type = if (variant.buildType == "release") "" else "-${variant.buildType}"
        val signed = if (variant.buildType == "debug" || hasReleaseKey) "" else "-unsigned"

        variant.outputs.forEach { output ->
            output.outputFileName.set("ShizuStore-$version$type$signed.apk")
        }
    }
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}

kotlin {
    compilerOptions {
        optIn.addAll(
            "androidx.compose.material3.ExperimentalMaterial3Api",
            "androidx.compose.material3.ExperimentalMaterial3ExpressiveApi",
            "androidx.compose.foundation.layout.ExperimentalLayoutApi",
            "kotlinx.serialization.ExperimentalSerializationApi"
        )
    }
}

// Recomposer-skipping and stability reports, opt-in because writing them slows
// every Compose module down: ./gradlew assembleRelease -PcomposeMetrics=true
composeCompiler {
    val enabled = providers.gradleProperty("composeMetrics").map(String::toBoolean).getOrElse(false)
    if (enabled) {
        metricsDestination.set(layout.buildDirectory.dir("compose-metrics"))
        reportsDestination.set(layout.buildDirectory.dir("compose-reports"))
    }
}

android {
    namespace = "me.timschneeberger.shizustore"
    compileSdk {
        version = release(37) {
            minorApiLevel = 0
        }
    }

    defaultConfig {
        applicationId = "me.timschneeberger.shizustore"
        minSdk = 24
        targetSdk = 37
        versionCode = appVersionCode
        versionName = appVersionName
        buildConfigField("String", "API_BASE_URL", "\"https://shizustore.timschneeberger.me/\"")
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                val properties = Properties().apply {
                    File("signing.properties").inputStream().use { load(it) }
                }

                keyAlias = properties["KEY_ALIAS"] as String
                keyPassword = properties["KEY_PASSWORD"] as String
                storeFile = file(properties["STORE_FILE"] as String)
                // Older local files only define KEY_PASSWORD for both.
                storePassword =
                    (properties["STORE_PASSWORD"] ?: properties["KEY_PASSWORD"]) as String
            }
        }
        create("aosp") {
            keyAlias = "testkey"
            keyPassword = "testkey"
            storeFile = file("testkey.jks")
            storePassword = "testkey"
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            signingConfig = signingConfigs.getByName("aosp")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasReleaseKey) {
                signingConfig = signingConfigs.getByName("release")
            }
            // AGP would embed the build commit in META-INF/version-control-info
            // .textproto, so the binary would change on every fastlane-only
            // commit and break F-Droid's reference APK comparison.
            vcsInfo {
                include = false
            }
        }

        register("nightly") {
            initWith(getByName("release"))
            applicationIdSuffix = ".nightly"
            versionNameSuffix = "-${lastCommitHash.get()}"
        }

        // Release-identical (R8) build for Macrobenchmark and baseline profile
        // generation; AOSP testkey so it installs here.
        create("benchmark") {
            initWith(getByName("release"))
            signingConfig = signingConfigs.getByName("aosp")
            isDebuggable = false
            isProfileable = true
            matchingFallbacks += listOf("release")
        }

        // The baseline profile producer runs one variant per prefix. Reusing
        // these build type names keeps its APKs AOSP-signed and installable
        // without the release keystore.
        create("benchmarkRelease") {
            initWith(getByName("benchmark"))
        }

        // Profile generation leans on unobfuscated class names; AGP maps them
        // through R8 when the real release build consumes the profile.
        create("nonMinifiedRelease") {
            initWith(getByName("release"))
            signingConfig = signingConfigs.getByName("aosp")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    buildFeatures {
        buildConfig = true
        compose = true
    }

    androidResources {
        // AGP derives LocaleConfig from the values-* folders, so a new
        // translation only needs its resource folder and no manual entry.
        generateLocaleConfig = true
    }

    dependenciesInfo {
        // AGP would embed a Google-encrypted dependency list in the signing
        // block; F-Droid's APK scanner rejects it.
        includeInApk = false
        includeInBundle = false
    }

    compileOptions {
        // java.time for ISO-8601 parsing; minSdk 24 predates it on Android.
        isCoreLibraryDesugaringEnabled = true
    }

    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}")
    }

    lint {
        lintConfig = file("lint.xml")
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

ktlint {
    android = true
    verbose = true
}

baselineProfile {
    // Keep the generated profile in app/src/main so release builds pick it up.
    saveInSrc = true
}

dependencies {
    coreLibraryDesugaring(libs.desugar.jdk.libs)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.paging.runtime)
    implementation(libs.androidx.paging.compose)
    implementation(libs.androidx.profileinstaller)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.browser)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.navigation3.runtime)
    implementation(libs.androidx.navigation3.ui)
    implementation(libs.androidx.lifecycle.navigation3)

    implementation(libs.kotlinx.serialization.json)
    implementation(libs.okhttp)
    implementation(libs.okhttp.brotli)

    implementation(libs.github.topjohnwu.libsu)
    implementation(libs.rikka.shizuku.api)
    implementation(libs.rikka.shizuku.provider)
    implementation(libs.rikka.tools.refine.runtime)
    implementation(libs.lsposed.hiddenapibypass)
    compileOnly(libs.rikka.hidden.stub)

    implementation(libs.coil.kt)
    implementation(libs.coil.compose)
    implementation(libs.coil.network)
    implementation(libs.coil.svg)

    implementation(libs.markdown.renderer)
    implementation(libs.markdown.renderer.m3)
    implementation(libs.markdown.renderer.code)

    implementation(libs.hilt.android.core)
    implementation(libs.androidx.hilt.viewmodel)
    implementation(libs.androidx.hilt.work)
    ksp(libs.hilt.android.compiler)
    ksp(libs.hilt.androidx.compiler)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.paging)
    implementation(libs.androidx.sqlite.bundled)
    ksp(libs.androidx.room.compiler)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.robolectric)
    testImplementation(libs.okhttp.mockwebserver)

    baselineProfile(project(":baselineprofile"))
}

tasks.withType<Test>().configureEach {
    maxParallelForks = (Runtime.getRuntime().availableProcessors() / 2).coerceAtLeast(1)
}
